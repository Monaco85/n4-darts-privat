@echo off
title n4-darts - Simulator
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1" -Simulator
echo.
pause
